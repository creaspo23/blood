<?php $__env->startSection('title'); ?>
    سحب الدم
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- plugin css -->
    <link href="<?php echo e(URL::asset('/assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
        <?php $__env->slot('pagetitle'); ?>
            السحب
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            سحب الدم
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-xl-6">
            <div class="card">
                <div class="card-body">
                    <?php if($type == 'donation'): ?>
                        <h4 class="card-title mb-4">بيانات المتبرع</h4>
                    <?php elseif($type == 'order'): ?>
                        <h4 class="card-title mb-4">بيانات المريض</h4>
                    <?php endif; ?>
                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">رقم العينة</div>
                        <div class="col-lg-9"> <?php echo e($case->id); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الاسم</div>
                        <div class="col-lg-9"> <?php echo e($case->person->name); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الجنس</div>
                        <div class="col-lg-9"> <?php echo e($case->person->gender); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">تاريخ الميلاد</div>
                        <div class="col-lg-9"> <?php echo e($case->person->birth_date); ?> </div>
                    </div>

                    <?php if($type == 'order'): ?>
                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold"> الوحدة </div>
                            <div class="col-lg-9"> <?php echo e($case->unit); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold"> التشخيص </div>
                            <div class="col-lg-9"> <?php echo e($case->diagnosis); ?> </div>
                        </div>
                    <?php endif; ?>

                    <?php if($type == 'donation'): ?>
                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">رقم الهاتف</div>
                            <div class="col-lg-9"> <?php echo e($case->person->phone); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">العنوان</div>
                            <div class="col-lg-9"> <?php echo e($case->person->address); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">المهنة</div>
                            <div class="col-lg-9"> <?php echo e($case->person->job_title); ?> </div>
                        </div>
                    <?php endif; ?>

                    <hr>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الفصيلة</div>
                        <div class="col-lg-9"> <?php echo e($case->person->blood_group); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">HB</div>
                        <div class="col-lg-9"> <?php echo e($case->bloodTest->HB ?? ''); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">ملاحظات </div>
                        <div class="col-lg-9"> <?php echo e($case->bloodTest->notes ?? ''); ?> </div>
                    </div>

                    <hr>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الوزن</div>
                        <div class="col-lg-9"> <?php echo e($case->doctorTest->weight ?? ''); ?> KG </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">ضغط الدم</div>
                        <div class="col-lg-9"> <?php echo e($case->doctorTest->BP ?? ''); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold"> ملاحظات الطبيب </div>
                        <div class="col-lg-9"> <?php echo e($case->doctorTest->notes ?? ''); ?> </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="col-xl-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4"> سحب الدم </h4>

                    <form method="post" action="<?php echo e(route('withdraw.store')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row mt-2">
                            <label class="form-label col-lg-3">وقت السحب</label>
                            <div class="col-lg-9">
                                <select name="time" id="time" class="form-control form-select">
                                    <option value="5">اقل من 5 دقائق</option>
                                    <option value="10">اقل من 10 دقائق</option>
                                    <option value="15">اقل من 15 دقبقة</option>
                                    <option value="20">اكثر من 15 دقيقة</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <label class="form-label col-lg-3">ملاحظات</label>
                            <div class="col-lg-9">
                                <textarea class="form-control" dir="rtl" name="notes"></textarea>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-9 offset-3">
                                <?php if($type == 'donation'): ?>
                                    <input type="hidden" name="donation_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>
                                <?php if($type == 'order'): ?>
                                    <input type="hidden" name="order_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>
                                <?php if($type == 'polcythemia'): ?>
                                <input type="hidden" name="polycythemias_id" value="<?php echo e($case->id); ?>">
                            <?php endif; ?>

                        <?php if($type == 'kid'): ?>
                        <input type="hidden" name="kid_id" value="<?php echo e($case->id); ?>">
                    <?php endif; ?>
                                <input type="hidden" name="faild" value="0" id="faild">
                                <button type="submit" class=" btn btn-primary btn-block">نجح السحب</button>
                                <button type="submit" onclick="failed()" class=" btn btn-danger btn-block">فشل
                                    السحب</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
        <script src="<?php echo e(URL::asset('/assets/libs/select2/select2.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('/assets/js/pages/form-advanced.init.js')); ?>"></script>
        <script>
            function failed(){
                let b=document.getElementById("faild").value = "1";
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/walieldin-nctr/Desktop/new blood/resources/views/blood-withdraw.blade.php ENDPATH**/ ?>