<?php $__env->startSection('title'); ?>
    فحص الذمرة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- plugin css -->
    <link href="<?php echo e(URL::asset('/assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
        <?php $__env->slot('pagetitle'); ?>
            فحص الذمرة
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            معمل الفحص
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-xl-6">
            <div class="card">
                <div class="card-body">
                    <?php if($type == 'donation'): ?>
                        <h4 class="card-title mb-4">بيانات المتبرع</h4>
                    <?php elseif($type == 'order'): ?>
                        <h4 class="card-title mb-4">بيانات المريض</h4>
                    <?php elseif($type=='kid'): ?>
                    <h4 class="card-title mb-4">بيانات المولود</h4>
                    <?php elseif($type=='mother'): ?>
                    <h4 class="card-title mb-4">بيانات الأم</h4>

                    <?php endif; ?>
                    <?php if($type=="mother"): ?>
                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">رقم العينة</div>
                    
                        <div class="col-lg-9"> <?php echo e($case->id); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الاسم</div>
                        <div class="col-lg-9"> <?php echo e($case->mothrName->name); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الجنس</div>
                        <div class="col-lg-9"> <?php echo e($case->mothrName->gender); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">تاريخ الميلاد</div>
                        <div class="col-lg-9"> <?php echo e($case->mothrName->birth_date); ?> </div>
                    </div>
                    <?php else: ?>
                    
                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">رقم العينة</div>
                    
                        <div class="col-lg-9"> <?php echo e($case->id); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الاسم</div>
                        <div class="col-lg-9"> <?php echo e($case->person->name); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الجنس</div>
                        <div class="col-lg-9"> <?php echo e($case->person->gender); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">تاريخ الميلاد</div>
                        <div class="col-lg-9"> <?php echo e($case->person->birth_date); ?> </div>
                    </div>
           
                    <?php endif; ?>
                    <?php if($type == 'order'): ?>
                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold"> الوحدة </div>
                            <div class="col-lg-9"> <?php echo e($case->unit); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold"> التشخيص </div>
                            <div class="col-lg-9"> <?php echo e($case->diagnosis); ?> </div>
                        </div>
                    <?php endif; ?>

                    <?php if($type == 'donation'): ?>
                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">رقم الهاتف</div>
                            <div class="col-lg-9"> <?php echo e($case->person->phone); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">العنوان</div>
                            <div class="col-lg-9"> <?php echo e($case->person->address); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">المهنة</div>
                            <div class="col-lg-9"> <?php echo e($case->person->job_title); ?> </div>
                        </div>
                    <?php endif; ?>

                    
                    
                    
                    

                </div>
            </div>
        </div>

        <div class="col-xl-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4"> فحص الدم </h4>

                    <form method="post" action="<?php echo e(route('bloodTest.store')); ?>">
                        
                        <div class="row">
                            <label class="form-label col-lg-3">الفصيلة</label>
                            <div class="col-lg-9">
                                <select class="form-control select2 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " dir="rtl"
                                    name="blood_group" id="blood_group" style="width: 100%">
                                    <option></option>
                                    <optgroup label="Positives">
                                        <option <?php echo e($case->person->blood_group == 'A+' ? 'selected' : ''); ?>>A+</option>
                                        <option <?php echo e($case->person->blood_group == 'B+' ? 'selected' : ''); ?>>B+</option>
                                        <option <?php echo e($case->person->blood_group == 'AB+' ? 'selected' : ''); ?>>AB+</option>
                                        <option <?php echo e($case->person->blood_group == 'O+' ? 'selected' : ''); ?>>O+</option>
                                    </optgroup>
                                    <optgroup label="Negatives">
                                        <option <?php echo e($case->person->blood_group == 'A-' ? 'selected' : ''); ?>>A-</option>
                                        <option <?php echo e($case->person->blood_group == 'B-' ? 'selected' : ''); ?>>B-</option>
                                        <option <?php echo e($case->person->blood_group == 'AB-' ? 'selected' : ''); ?>>AB-</option>
                                        <option <?php echo e($case->person->blood_group == 'O-' ? 'selected' : ''); ?>>O-</option>
                                    </optgroup>
                                </select>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <?php if($type[1] == 'mother'): ?>
                            <div class="row">
                                <label class="form-label col-lg-3">الفصيلة</label>
                                <div class="col-lg-9">
                                    <select class="form-control select2 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " dir="rtl"
                                        name="blood_group" id="blood_group" style="width: 100%">
                                        <option></option>
                                        <optgroup label="Positives">
                                            <option <?php echo e($case->mothrName->blood_group == 'A+' ? 'selected' : ''); ?>>A+
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'B+' ? 'selected' : ''); ?>>B+
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'AB+' ? 'selected' : ''); ?>>AB+
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'O+' ? 'selected' : ''); ?>>O+
                                            </option>
                                        </optgroup>
                                        <optgroup label="Negatives">
                                            <option <?php echo e($case->mothrName->blood_group == 'A-' ? 'selected' : ''); ?>>A-
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'B-' ? 'selected' : ''); ?>>B-
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'AB-' ? 'selected' : ''); ?>>AB-
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'O-' ? 'selected' : ''); ?>>O-
                                            </option>
                                        </optgroup>
                                    </select>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="row mt-2">
                            <label class="form-label col-lg-3">Genotype</label>
                            <div class="col-lg-9">
                                <select class="form-control select2 <?php $__errorArgs = ['genotype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" dir="rtl"
                                    name="genotype" id="genotype" style="width: 100%">
                                    <option></option>
                                    <optgroup label="Positives">
                                        <option <?php echo e($case->person->blood_group == 'C+' ? 'selected' : ''); ?>>C+</option>
                                        <option <?php echo e($case->person->blood_group == 'c+' ? 'selected' : ''); ?>>c+</option>
                                        <option <?php echo e($case->person->blood_group == 'E+' ? 'selected' : ''); ?>>E+</option>
                                        <option <?php echo e($case->person->blood_group == 'e+' ? 'selected' : ''); ?>>e+</option>
                                        <option <?php echo e($case->person->blood_group == 'kell+' ? 'selected' : ''); ?>>kell+</option>
                                    </optgroup>
                                    <optgroup label="Negatives">
                                        <option <?php echo e($case->person->blood_group == 'C-' ? 'selected' : ''); ?>>C-</option>
                                        <option <?php echo e($case->person->blood_group == 'c-' ? 'selected' : ''); ?>>c-</option>
                                        <option <?php echo e($case->person->blood_group == 'E-' ? 'selected' : ''); ?>>E-</option>
                                        <option <?php echo e($case->person->blood_group == 'e-' ? 'selected' : ''); ?>>e-</option>
                                        <option <?php echo e($case->person->blood_group == 'kell-' ? 'selected' : ''); ?>>kell-</option>
                                    </optgroup>
                                </select>
                                <?php $__errorArgs = ['genotype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <?php if($type[1] == 'mother'): ?>
                            <div class="row mt-2">
                                <label class="form-label col-lg-3">Genotype</label>
                                <div class="col-lg-9">
                                    <select class="form-control select2 <?php $__errorArgs = ['genotype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        dir="rtl" name="genotype" id="genotype" style="width: 100%">
                                        <option></option>
                                        <optgroup label="Positives">
                                            <option <?php echo e($case->mothrName->blood_group == 'C+' ? 'selected' : ''); ?>>C+
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'c+' ? 'selected' : ''); ?>>c+
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'E+' ? 'selected' : ''); ?>>E+
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'e+' ? 'selected' : ''); ?>>e+
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'kell+' ? 'selected' : ''); ?>>kell+
                                            </option>
                                        </optgroup>
                                        <optgroup label="Negatives">
                                            <option <?php echo e($case->mothrName->blood_group == 'C-' ? 'selected' : ''); ?>>C-
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'c-' ? 'selected' : ''); ?>>c-
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'E-' ? 'selected' : ''); ?>>E-
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'e-' ? 'selected' : ''); ?>>e-
                                            </option>
                                            <option <?php echo e($case->mothrName->blood_group == 'kell-' ? 'selected' : ''); ?>>kell-
                                            </option>
                                        </optgroup>
                                    </select>
                                    <?php $__errorArgs = ['genotype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                      <?php if($type=="mother"): ?> 
                      

                       <div class="row mt-2">
                        <label class="form-label col-lg-3">HB</label>
                        <div class="col-lg-9">
                            <input class="form-control <?php $__errorArgs = ['HB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" dir="rtl"
                                value="<?php echo e($case->motherBloodTest ? $case->motherBloodTest->HB : ''); ?>" type="number"
                                value="12" name="HB">
                        </div>
                    </div>
                    <?php $__errorArgs = ['HB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="row mt-2">
                        <label class="form-label col-lg-3">ملاحظات</label>
                        <div class="col-lg-9">
                            <textarea class="form-control" dir="rtl" name="notes">
                            <?php echo e($case->motherBloodTest ? $case->motherBloodTest->notes : ''); ?>

                        </textarea>
                        </div>
                    </div>
                      
                      <?php else: ?>
                      <div class="row mt-2">
                        <label class="form-label col-lg-3">HB</label>
                        <div class="col-lg-9">
                            <input class="form-control <?php $__errorArgs = ['HB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" dir="rtl"
                                value="<?php echo e($case->bloodTest ? $case->bloodTest->HB : ''); ?>" type="number"
                                value="12" name="HB">
                        </div>
                    </div>
                    <?php $__errorArgs = ['HB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="row mt-2">
                            <label class="form-label col-lg-3">ملاحظات</label>
                            <div class="col-lg-9">
                                <textarea class="form-control" dir="rtl" name="notes">
                                <?php echo e($case->bloodTest ? $case->bloodTest->notes : ''); ?>

                            </textarea>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="row mt-2">
                            <div class="col-lg-9 offset-3">
                                <?php echo csrf_field(); ?>
                                <?php if($type == 'donation'): ?>
                                    <input type="hidden" name="donation_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>
                                <?php if($type == 'order'): ?>
                                    <input type="hidden" name="order_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>

                                <?php if($type == 'polcythemia'): ?>
                                    <input type="hidden" name="polycythemias_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>

                                <?php if($type == 'kid'): ?>
                                    <input type="hidden" name="kid_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>
                                
                                <?php if($type == 'mother'): ?>
                                    <input type="hidden" name="mother_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>
                                <button type="submit" class=" btn btn-primary btn-block">حفظ</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
        <script src="<?php echo e(URL::asset('/assets/libs/select2/select2.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('/assets/js/pages/form-advanced.init.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/walieldin-nctr/Desktop/blood_banck-wali/resources/views/bloodTest.blade.php ENDPATH**/ ?>