<?php $__env->startSection('title'); ?>
    فحص الذمرة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- plugin css -->
    <link href="<?php echo e(URL::asset('/assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
        <?php $__env->slot('pagetitle'); ?>
            الفحص
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            فحص الطبيب
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-xl-6">
            <div class="card">
                <div class="card-body">
                    <?php if($type == 'donation'): ?>
                        <h4 class="card-title mb-4">بيانات المتبرع</h4>
                    <?php elseif($type == 'order'): ?>
                        <h4 class="card-title mb-4">بيانات المريض</h4>
                    <?php endif; ?>
                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">رقم العينة</div>
                        <div class="col-lg-9"> <?php echo e($case->id); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الاسم</div>
                        <div class="col-lg-9"> <?php echo e($case->person->name); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الجنس</div>
                        <div class="col-lg-9"> <?php echo e($case->person->gender); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">تاريخ الميلاد</div>
                        <div class="col-lg-9"> <?php echo e($case->person->birth_date); ?> </div>
                    </div>

                    <?php if($type == 'order'): ?>
                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold"> الوحدة </div>
                            <div class="col-lg-9"> <?php echo e($case->unit); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold"> التشخيص </div>
                            <div class="col-lg-9"> <?php echo e($case->diagnosis); ?> </div>
                        </div>
                    <?php endif; ?>

                    <?php if($type == 'donation'): ?>
                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">رقم الهاتف</div>
                            <div class="col-lg-9"> <?php echo e($case->person->phone); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">العنوان</div>
                            <div class="col-lg-9"> <?php echo e($case->person->address); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">المهنة</div>
                            <div class="col-lg-9"> <?php echo e($case->person->job_title); ?> </div>
                        </div>
                    <?php endif; ?>

                    <hr>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الفصيلة</div>
                        <div class="col-lg-9"> <?php echo e($case->person->blood_group); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">HB</div>
                        <div class="col-lg-9"> <?php echo e($case->bloodTest->HB ?? ''); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">ملاحظات </div>
                        <div class="col-lg-9"> <?php echo e($case->bloodTest->notes ?? ''); ?> </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="col-xl-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4"> فحص الطبيب</h4>

                    <form method="post" action="<?php echo e(route('doctorTest.store')); ?>">
                        <div class="row mt-2">
                            <label class="form-label col-lg-3">BP</label>
                            <div class="col-lg-9">
                                <input class="form-control <?php $__errorArgs = ['BP'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" dir="rtl"
                                    value="<?php echo e($case->doctorTest ? $case->doctorTest->BP : ''); ?>" type="number"
                                    name="BP">
                                <?php $__errorArgs = ['BP'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <label class="form-label col-lg-3">الوزن</label>
                            <div class="col-lg-9">
                                <input class="form-control <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" dir="rtl"
                                    type="number" value="<?php echo e($case->doctorTest ? $case->doctorTest->weight : ''); ?>"
                                    name="weight">
                                <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <label class="form-label col-lg-3">اخرى</label>
                            <div class="col-lg-9">
                                <select class="select2 form-control select2-multiple" name="others[]" dir="rtl"
                                    multiple="multiple" data-placeholder="حدد" style="width: 100%">
                                    <option>تبرع بالدم اقل من 3 شهور</option>
                                    <option>ضغط مزمن</option>
                                    <option>سكري</option>
                                    <option>علاقات جنسية متطرفة</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <label class="form-label col-lg-3">ملاحظات</label>
                            <div class="col-lg-9">
                                <textarea class="form-control" dir="rtl" name="notes"><?php echo e($case->doctorTest ? $case->doctorTest->notes : ''); ?></textarea>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-9 offset-3">
                                <?php echo csrf_field(); ?>
                                <?php if($type == 'donation'): ?>
                                    <input type="hidden" name="donation_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>
                                <?php if($type == 'order'): ?>
                                    <input type="hidden" name="order_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>
                                <?php if($type == 'polcythemia'): ?>
                                    <input type="hidden" name="polycythemias_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>

                                <?php if($type == 'kid'): ?>
                                    <input type="hidden" name="kid_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>

                                <?php if($type == 'kid'): ?>
                                    <input type="hidden" name="kid_id" value="<?php echo e($case->id); ?>">
                                <?php endif; ?>
                                <button type="submit" class=" btn btn-primary btn-block">حفظ</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
        <script src="<?php echo e(URL::asset('/assets/libs/select2/select2.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('/assets/js/pages/form-advanced.init.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/walieldin-nctr/Desktop/blood_banck-wali/resources/views/doctorTest.blade.php ENDPATH**/ ?>