<div class="dropdown d-inline-block">
    <a type="button" class="btn btn-outline-primary" id="page-header-user-dropdown" data-bs-toggle="dropdown"
        aria-haspopup="true" aria-expanded="false">
        <i class="uil-ellipsis-v d-none d-xl-inline-block font-size-1"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-end">
        <!-- item-->

        
        <?php if($order->status == 'ملغي' || $order->status == 'مرفوض' || $order->bloodTest): ?>
            <a class="dropdown-item" href="#" style="cursor: not-allowed;color: grey"> <span class="align-middle">
                    فحص الزمره </span></a>
        <?php else: ?>
            <a class="dropdown-item" href="<?php echo e(url('/tests/' . $test[0] . '/' . $type . '/' . $order->id)); ?>"> <span
                    class="align-middle"> فحص الزمره </span></a>
        <?php endif; ?>
        


        
        <?php if($order->status == 'ملغي' || $order->status == 'مرفوض' || $order->status == 'مكتمل'): ?>
            <a class="dropdown-item" style="cursor: not-allowed;color: grey" href="#">
                <span class="align-middle">إلغاء الطلب</span>
            </a>
        <?php else: ?>
            <a class="dropdown-item"
                onclick="event.preventDefault(); document.getElementById('profile-activate-<?php echo e($order->id); ?>').submit();"
                href="#">
                <span class="align-middle">إلغاء الطلب</span>
            </a>
        <?php endif; ?>
        <a class="dropdown-item" href="<?php echo e(route('print-order', $order->id)); ?>"> <span class="align-middle">
                طباعه </span>
        </a>
        
        <form id="profile-activate-<?php echo e($order->id); ?>" action="<?php echo e(route('updateStatus', $order->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
        </form>

        <?php if($order->donation != null &&
            $order->donation->doctorTest &&
            $order->donation->bloodTest &&
            $order->donation->viralTest &&
            $order->bloodTest): ?>
            <a class="dropdown-item" href="<?php echo e(route('exchanges', $order->id)); ?>"> <span class="align-middle"> صرف الدم
                </span></a>
        <?php elseif($order->status == 'مكتمل'): ?>
            <a class="dropdown-item" style="cursor: not-allowed;color: grey" href="#"> <span class="align-middle">
                    صرف الدم
                </span></a>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH /home/walieldin-nctr/Desktop/new blood/resources/views/partials/order-options.blade.php ENDPATH**/ ?>