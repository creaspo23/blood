<?php $__env->startSection('title'); ?>
    التجانس
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- plugin css -->
    <link href="<?php echo e(URL::asset('/assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
        <?php $__env->slot('pagetitle'); ?>
            التجانس
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            فحص التجانس
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-xl-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">بيانات المريض</h4>
                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">رقم الطلب</div>
                        <div class="col-lg-9"> <?php echo e($dontion->id); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الوحدة</div>
                        <div class="col-lg-9"> <?php echo e($dontion->order->hospital); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الاسم</div>
                        <div class="col-lg-9"> <?php echo e($dontion->order->person->name); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">تاريخ الميلاد</div>
                        <div class="col-lg-9"> <?php echo e($dontion->order->person->birth_date); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الفصيلة</div>
                        <div class="col-lg-9"><?php echo e($dontion->order->person->blood_group); ?> </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">نوع الدم</div>
                        <div class="col-lg-9">
                            <?php $__currentLoopData = $dontion->order->bloods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($blood->blood_type . ' '); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-3 font-weight-bold" style="font-weight: bold">تاريخ الطلب</div>
                        <div class="col-lg-9"> <?php echo e($dontion->order->created_at->format('y-m-d')); ?> </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="col-xl-6">
            <div>
                <div class="card ">
                    <div class="card-body">

                        <form method="POST" action="<?php echo e(route('homogeneity.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row mt-2">
                                <label class="form-label col-lg-3">نوع الدم</label>
                                <div class="col-lg-9">
                                    <select class="select2 form-control select2-multiple" dir="rtl" multiple="multiple"
                                        data-placeholder="حدد" style="width: 100%"  >
                                        <optgroup label="">
                                            <?php $__currentLoopData = $dontion->order->bloods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($blood->blood_type); ?>"> <?php echo e($blood->blood_type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </optgroup>
                                    </select>
                                </div>
                            </div>

                            <div class="row mt-2">
                                <label class="form-label col-lg-3">الزجاجات</label>
                                <div class="col-lg-9">
                                    <select class="select2 form-control select2-multiple" dir="rtl" multiple="multiple"
                                        data-placeholder="حدد" style="width: 100%" name="bottels[]">

                                        <optgroup label="">
                                            <?php $__currentLoopData = $bottels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bottel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($bottel->bottle_number); ?>"><?php echo e($bottel->bottle_number); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </optgroup>
                                    </select>
                                </div>
                            </div>
                    </div>
                </div>
            </div>

            <div>
                <div class="card mb-4">
                    <div class="card-body">
                        <h4 class="card-title mb-4"> بيانات الزجاجة </h4>
   
                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">رقم الزجاجة</div>
                            <div class="col-lg-9"> <?php echo e($dontion->bloodWithdraw->bottle_number); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">الفصيلة</div>
                            <div class="col-lg-9"> <?php echo e($dontion->person->blood_group); ?> </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">نوع الدم</div>
                            <div class="col-lg-9"> بلازما </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-lg-3 font-weight-bold" style="font-weight: bold">تاريخ الصلاحية</div>
                            <div class="col-lg-9">
                                <?php echo e($dontion->bloodWithdraw->created_at->format('y-m-d /H:I:s')); ?>

                            </div>
                        </div>

                    </div>

                </div>
            </div>

            <div>
                <div class="card mt-4">
                    <div class="card-body">
                        <h4 class="card-title mb-4"> تجانس الدم </h4>


                            <div class="row mt-2">
                                <label class="form-label col-lg-3">ملاحظات</label>
                                <div class="col-lg-9">
                                    <textarea class="form-control" dir="rtl" name="note"></textarea>
                                </div>
                            </div>

                            <div class="row mt-2">
                                <div class="col-lg-9 offset-3">
                                    <input type="hidden" name="order_id" id="" value="<?php echo e($dontion->order->id); ?>">
                                    <input type="hidden" name="dontion_id" id="" value="<?php echo e($dontion->id); ?>">
                                    <input type="hidden" name="person_id" id="" value="<?php echo e($dontion->person->id); ?>">

                                    <button type="submit" class=" btn btn-primary btn-block">نجحت العملية</button>
                                    <button type="submit" class=" btn btn-danger btn-block"> فشلت</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
        <script src="<?php echo e(URL::asset('/assets/libs/select2/select2.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('/assets/js/pages/form-advanced.init.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/walieldin-nctr/Desktop/blood_banck-wali/resources/views/homogeneity.blade.php ENDPATH**/ ?>