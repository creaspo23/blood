<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0"><?php echo e($title); ?></h4>

            <div class="page-title-right" dir="rtl">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($pagetitle); ?></a></li>
                    <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title --><?php /**PATH /home/walieldin-nctr/Desktop/blood_banck-wali/resources/views/common-components/breadcrumb.blade.php ENDPATH**/ ?>