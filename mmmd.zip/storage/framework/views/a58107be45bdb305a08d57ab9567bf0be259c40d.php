<div class="dropdown d-inline-block">
    <a type="button" class="btn btn-outline-primary" id="page-header-user-dropdown" data-bs-toggle="dropdown"
        aria-haspopup="true" aria-expanded="false">
        <i class="uil-ellipsis-v d-none d-xl-inline-block font-size-1"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-end">
        <!-- item-->
        <?php if($polcythemia->status == 'ملغي' || $polcythemia->status == 'مرفوض' || $polcythemia->bloodTest): ?>
            

            <a class="dropdown-item" href="#" style="cursor: not-allowed;color: grey"> <span class="align-middle">
                    فحص الدم </span></a>
        <?php else: ?>
            <a class="dropdown-item"
                href="<?php echo e(url('/tests/' . $test[0] . '/' . $type . '/' . $polcythemia->id)); ?>"> <span
                    class="align-middle"> فحص الدم </span></a>
        <?php endif; ?>
        <?php if($polcythemia->status == 'ملغي' ||
            $polcythemia->status == 'مرفوض' ||
            $polcythemia->doctorTest ||
            $polcythemia->bloodTest == null): ?>
            <a class="dropdown-item" href="#" style="cursor: not-allowed;color: grey"> <span class="align-middle">
                    فحص الطبيب </span></a>
        <?php else: ?>
            <a class="dropdown-item" href="<?php echo e(url('/tests/' . $test[1] . '/' . $type . '/' . $polcythemia->id)); ?>">
                <span class="align-middle"> فحص الطبيب </span></a>
        <?php endif; ?>
        
        <?php if($polcythemia->status == 'ملغي' ||
            $polcythemia->status == 'مرفوض' ||
            $polcythemia->bloodWithdraw ||
            $polcythemia->doctorTest == null): ?>
            <a class="dropdown-item" href="#" style="cursor: not-allowed;color: grey"> <span class="align-middle">
                    سحب الدم </span></a>
        <?php else: ?>
            <a class="dropdown-item" href="<?php echo e(url('/withdraw' . '/' . $type . '/' . $polcythemia->id)); ?>"> <span
                    class="align-middle"> سحب الدم </span></a>
        <?php endif; ?>
        
        


        


        
        

        
        
        <a class="dropdown-item" href="<?php echo e(route('printPolcythemias', $polcythemia->id)); ?>"> <span class="align-middle">
            طباعه </span>
        </a>
        
        <?php if($polcythemia->status == 'ملغي' || $polcythemia->status == 'مرفوض' || $polcythemia->status == 'مكتمل'): ?>
            <a class="dropdown-item" style="cursor: not-allowed;color: grey" href="#">
                <span class="align-middle">إلغاء التبرع</span>
            </a>
        <?php else: ?>
            <a class="dropdown-item"
                onclick="event.preventDefault(); document.getElementById('profile-activate-<?php echo e($polcythemia->id); ?>').submit();"
                href="#">
                <span class="align-middle">إلغاء التبرع</span>
            </a>
        <?php endif; ?>

        

        <form id="profile-activate-<?php echo e($polcythemia->id); ?>" action="<?php echo e(route('cancelPolcythemias', $polcythemia->id)); ?>"
            method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
        </form>




    </div>
</div>
<?php /**PATH /home/walieldin-nctr/Desktop/blood_banck-wali/resources/views/partials/polcythemia-option.blade.php ENDPATH**/ ?>