<!-- JAVASCRIPT -->
 <script src="<?php echo e(URL::asset('/assets/libs/jquery/jquery.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('/assets/libs/bootstrap/bootstrap.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('/assets/libs/metismenu/metismenu.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('/assets/libs/simplebar/simplebar.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('/assets/libs/node-waves/node-waves.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('/assets/libs/waypoints/waypoints.min.js')); ?>"></script>
 <script src="<?php echo e(URL::asset('/assets/libs/jquery-counterup/jquery-counterup.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/assets/libs/toastr/toastr.min.js')); ?>"></script>

<script>
    toastr.options = {
        "closeButton": true,
        "newestOnTop": true,
        "progressBar": true,
        "positionClass": "toast-top-left",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    <?php if(session('success')): ?>
    $(document).ready(function onDocumentReady() {
        toastr.success("<?php echo e(session('success')); ?>");
    });
    <?php endif; ?>

    <?php if(session('error')): ?>
    $(document).ready(function onDocumentReady() {
        toastr.error("<?php echo e(session('error')); ?>");
    });
    <?php endif; ?>
</script>

 <?php echo $__env->yieldContent('script'); ?>

 <!-- App js -->
 <script src="<?php echo e(URL::asset('/assets/js/app.min.js')); ?>"></script>

 <?php echo $__env->yieldContent('script-bottom'); ?>
<?php /**PATH /home/walieldin-nctr/Desktop/blood_banck-wali/resources/views/layouts/vendor-scripts.blade.php ENDPATH**/ ?>