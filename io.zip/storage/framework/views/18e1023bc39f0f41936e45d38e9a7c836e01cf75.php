<?php $__env->startSection('title'); ?>  الامراض الفيروسية <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- plugin css -->
    <link href="<?php echo e(URL::asset('/assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <style>
    
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
        <?php $__env->slot('pagetitle'); ?> النظام <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>   الامراض الفيروسية <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('viralDiseases.store')); ?>" method="post">
                        <div class="row">
                            <div class="col-lg-8">
                                <input type="text" name="name" class="form-control" placeholder="اسم المرض الفيروسي">
                            </div>
                            <div class="col-lg-2 pt-2">
                                <input class="form-check-input" name="permanent" value="1" type="checkbox" id="permanent">
                                <label class="form-check-label" for="permanent">
                                    مزمن
                                </label>
                            </div>
                            <div class="col-lg-2">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-primary" type="submit">حفظ</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-rep-plugin">
                        <div class="table-responsive mb-0" data-pattern="priority-columns">
                            <table id="tech-companies-1" class="table">
                                <thead>
                                <tr>
                                    <th data-priority="1">#</th>
                                    <th data-priority="1">الاسم</th>
                                    <th data-priority="1">مزمن</th>
                                    <th data-priority="1">تعديل</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr >
                                        <td>
                                            <?php echo e($disease->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($disease->name); ?>

                                        </td>
                                        <td>
                                            <?php if($disease->permanent == 1): ?>
                                                مزمن
                                            <?php else: ?>
                                                غير مزمن
                                            <?php endif; ?>
                                        </td>
                                        <td style="width: 100px">
                                            <a class="btn btn-outline-secondary btn-sm edit" title="Edit" data-bs-toggle="modal" data-bs-target="#modal-<?php echo e($disease->id); ?>">
                                                <i class="fas fa-pencil-alt"></i>
                                            </a>

                                            <!--  Large modal example -->
                                            <div class="modal fade bs-example-modal-lg" id="modal-<?php echo e($disease->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title mt-0" id="myLargeModalLabel"> تعديل </h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route('viralDiseases.store')); ?>" method="post">
                                                                <div class="row">
                                                                    <div class="col-lg-8">
                                                                        <input type="text" name="name" class="form-control" value="<?php echo e($disease->name); ?>" placeholder="اسم المرض الفيروسي">
                                                                    </div>
                                                                    <div class="col-lg-2 pt-2">
                                                                        <input class="form-check-input" name="permanent" value="1" type="checkbox" <?php echo e($disease->permanent == '1'? 'checked' : ''); ?>  id="permanent">
                                                                        <label class="form-check-label" for="permanent">
                                                                            مزمن
                                                                        </label>
                                                                    </div>
                                                                    <div class="col-lg-2">
                                                                        <?php echo csrf_field(); ?>
                                                                        <input type="hidden" name="id" value="<?php echo e($disease->id); ?>">
                                                                        <button class="btn btn-primary" type="submit">حفظ</button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div><!-- /.modal-content -->
                                                </div><!-- /.modal-dialog -->
                                            </div><!-- /.modal -->

                                            <a href="" class="btn btn-outline-secondary btn-sm edit" title="delete" onclick="event.preventDefault();
                                                     document.getElementById('delete-form-<?php echo e($disease->id); ?>').submit();">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>

                                            <form id="delete-form-<?php echo e($disease->id); ?>" action="<?php echo e(route('viralDiseases.destroy', $disease->id)); ?>" method="POST" style="display: none;">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('/assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/js/pages/form-advanced.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/walieldin-nctr/Desktop/blood_banck-wali/resources/views/viral-diseases.blade.php ENDPATH**/ ?>