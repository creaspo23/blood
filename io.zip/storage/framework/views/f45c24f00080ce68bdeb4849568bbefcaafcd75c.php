<?php $__env->startSection('title'); ?>
    سجل التبرعات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- plugin css -->
    <link href="<?php echo e(URL::asset('/assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('/assets/libs/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
        <?php $__env->slot('pagetitle'); ?>
            السجل
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            سجل التبرعات
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">

                    

                    <div class="table-responsive mt-4">
                        <table id="myTable" class="table table-bordered dt-responsive nowrap"
                            style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>الاسم</th>
                                    <th>الوحدة</th>
                                    <th>الفصيلة </th>
                                    <th>النوع </th>
                                    <th>الكمية </th>
                                    <th>تاريخ الطلب</th>
                                    <th>الحالة</th>
                                    <th>الخيارات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($donation->id); ?></td>
                                        <td><?php echo e($donation->person->name ?? ''); ?></td>
                                        <td><?php echo e($donation->order->unit ?? ''); ?></td>
                                        <td><?php echo e($donation->order->person->blood_group ?? ''); ?></td>
                                        <td>
                                            <?php if(is_array($donation->order) || is_object($donation->order)): ?>
                                            <?php $__currentLoopData = $donation->order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($order->bloods->blood_type ?? ''); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(is_array($donation->order) || is_object($donation->order)): ?>
        
                                                <?php $__currentLoopData = $donation->order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($order->bloods->quantity ?? ''); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($donation->order->created_at ?? ''); ?></td>
                                        <td>
                                            <?php if($donation->status == 'الانتظار'): ?>
                                                <span class="badge bg-soft-warning" style="font-size:small ">الإنتظار</span>
                                            <?php elseif($donation->status == 'مكتمل'): ?>
                                                <span class="badge bg-soft-success" style="font-size:small ">مكتمل</span>
                                            <?php elseif($donation->status == 'مرفوض'): ?>
                                                <span class="badge bg-soft-danger" style="font-size:small ">
                                                    مرفوض
                                                </span>
                                            <?php elseif($donation->status == 'ملغي'): ?>
                                                <span class="badge bg-soft-secondary" style="font-size:small ">ملغي</span>
                                            <?php endif; ?>
                                        </td>

                                        <td><?php echo $__env->make('partials.donation-options', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>
                    </div>
                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col-->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('/assets/libs/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/libs/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/libs/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/js/pages/datatables.init.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable({
                responsive: true,
                autoWidth: false,

            });

        });
    </script>
    <script src="<?php echo e(URL::asset('/assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/js/pages/form-advanced.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/walieldin-nctr/Desktop/blood_banck-wali/resources/views/donors.blade.php ENDPATH**/ ?>