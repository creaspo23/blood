<?php $__env->startSection('title'); ?> الموظفين <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- plugin css -->
    <link href="<?php echo e(URL::asset('/assets/libs/rwd-table/rwd-table.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
        <?php $__env->slot('pagetitle'); ?> الموظفين <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?> النظام <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <div class="float-end">
                        <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-primary">اضافة</a>
                    </div>

                    <h4 class="card-title">اضافة موظف</h4>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-rep-plugin">
                        <div class="table-responsive mb-0" data-pattern="priority-columns">
                            <table id="tech-companies-1" class="table">
                            <thead>
                                <tr>
                                    <th data-priority="1">#</th>
                                    <th data-priority="1">الاسم</th>
                                    <th data-priority="1">الوظيفة</th>
                                    <th data-priority="1">الوحدة</th>
                                    <th data-priority="1">الايميل</th>
                                    <th data-priority="1">تعديل</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr >
                                        <td>
                                            <?php echo e($employee->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($employee->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($employee->job_title); ?>

                                        </td>
                                        <td>
                                            <?php echo e($employee->unit); ?>

                                        </td>
                                        <td>
                                            <?php echo e($employee->user->email); ?>

                                        </td>
                                        <td style="width: 100px">
                                            <a href="<?php echo e(route('employees.edit', $employee->id)); ?>" class="btn btn-outline-secondary btn-sm edit" title="Edit">
                                                <i class="fas fa-pencil-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(URL::asset('/assets/libs/rwd-table/rwd-table.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/assets/js/pages/table-responsive.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/walieldin-nctr/Desktop/blood_banck-wali/resources/views/employees.blade.php ENDPATH**/ ?>