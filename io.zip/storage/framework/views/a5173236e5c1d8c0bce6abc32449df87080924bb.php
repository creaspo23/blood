<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <!-- LOGO -->
    <div class="navbar-brand-box">
        <a href="<?php echo e(url('/')); ?>" class="logo logo-dark">
            
        </a>

        <a href="<?php echo e(url('/')); ?>" class="logo logo-light">

    </div>

    <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect vertical-menu-btn">
        <i class="fa fa-fw fa-bars"></i>
    </button>

    <div data-simplebar class="sidebar-menu-scroll">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">القائمة</li>
                
                <li>

                    <a href="<?php echo e(url('/')); ?>">
                        <i class="uil-clinic-medical"></i>
                        <span> لوحةالتحكم</span>
                    </a>
                </li>
                


                <li class="menu-title">بنك الدم</li>

                <li>
                    

                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-heart-medical"></i>
                        <span>
                            الدم
                        </span>
                    </a>
                    

                    <ul>

                        <li>
                            
                            <a href="<?php echo e(route('orders.index')); ?>">
                                <i class="uil-telescope"></i>
                                <span>
                                    الطلبات
                                </span>
                            </a>
                            

                        </li>
                        
                        <li>
                            <a href="<?php echo e(route('orders.create')); ?>">
                                <i class="uil-comment-medical"></i>
                                <span>
                                    اضافة طلب
                                </span>
                            </a>
                        </li>
                        

                    </ul>
                </li>
                <li>

                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-social-distancing"></i>
                        <span>
                            التبرعات
                        </span>
                    </a>
                    <ul>
                        <li>
                            
                            <a href="<?php echo e(route('donations.create')); ?>">
                                <i class="uil-user-arrows"></i>
                                <span>
                                    اضافة تبرع
                                </span>
                            </a>
                            

                        </li>
                        <li>
                            <a href="<?php echo e(route('donations.index')); ?>">
                                <i class="uil-files-landscapes-alt"></i>
                                <span>
                                    سجل التبرعات
                                </span>
                            </a>
                        </li>

                    </ul>
                </li>

                
                <li>

                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-social-distancing"></i>
                        <span> الاطفال حديثي الولادة

                        </span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('kids.create')); ?>">
                                <i class="uil-user"></i>
                                <span>
                                    اضافة طفل
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('kids.index')); ?>">
                                <i class="uil-files-landscapes-alt"></i>
                                <span>
                                    سجل الاطفال
                                </span>
                            </a>
                        </li>

                    </ul>
                </li>

                <li>

                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-social-distancing"></i>
                        <span> الفحوصات الاخرى

                        </span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('investigations.create')); ?>">
                                <i class="uil-user"></i>
                                <span>
                                    عمل فحص
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('investigations.index')); ?>">
                                <i class="uil-files-landscapes-alt"></i>
                                <span>
                                    سجل الفحوصات
                                </span>
                            </a>
                        </li>

                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-social-distancing"></i>
                        <span>
                            الدم الزائد
                        </span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('polcythemias.create')); ?>">
                                <i class="uil-heart-rate"></i>
                                <span>
                                    زيادة الدم
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('polcythemias.index')); ?>">
                                <i class="uil-files-landscapes-alt"></i>
                                <span>
                                    سجل زيادة الدم
                                </span>
                            </a>
                        </li>

                    </ul>
                </li>

                



                

                <li>
                    
                    <a href="<?php echo e(route('employees.index')); ?>">
                        <i class="uil-users-alt"></i>
                        <span>
                            الموظفين
                        </span>
                    </a>
                    

                </li>

                <li>
                    
                    <a href="<?php echo e(route('viralDiseases.index')); ?>">
                        <i class="uil-home-alt"></i>
                        <span>
                            الأمراض الفيروسية </span>
                    </a>
                    

                </li>
                <li>

                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="uil-social-distancing"></i>
                        <span>
                            التقارير
                        </span>
                    </a>
                    <ul>

                        <li>
                            <a href="<?php echo e(route('BloodDischarged')); ?>">
                                <i class="uil-home-alt"></i>
                                <span>
                                    تقرير بنك الدم </span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('viralDiseases-invoice')); ?>">
                                <i class="uil-home-alt"></i>
                                <span>
                                    تقرير الفحص الفيروسي </span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('exclusionFromTheDoctor')); ?>">
                                <i class="uil-home-alt"></i>
                                <span>
                                    تقرير استبعاد من الطبيب </span></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('doners-WithDraw')); ?>">
                                <i class="uil-home-alt"></i>
                                <span>
                                    تقرير عدم السحب </span></a>
                        </li>
               
                        <li>
                            <a href="<?php echo e(route('polcythemiasrReport')); ?>">
                                <i class="uil-home-alt"></i>
                                <span>
                                    تقرير مرضي زياده الدم </span></a>
                        </li>


                    </ul>
                </li>

            </ul>
        </div>

        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH /home/walieldin-nctr/Desktop/new blood/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>