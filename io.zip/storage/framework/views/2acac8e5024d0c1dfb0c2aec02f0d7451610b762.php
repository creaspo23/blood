<?php $__env->startSection('title'); ?>
    سجل الفحوصات الاخري
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- plugin css -->
    <link href="<?php echo e(URL::asset('/assets/libs/datatables/datatables.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('common-components.breadcrumb'); ?>
        <?php $__env->slot('pagetitle'); ?>
            السجل
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('title'); ?>
            الفحوصات الاخري
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="card-title" style="text-align: center">

                                </h4>

                            </div>
                        </div>
                    </div>

                    <table id="myTable" class="table table-bordered dt-responsive nowrap"
                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>اسم المريض</th>
                                <th> النوع</th>
                                <th> تاريخ الميلاد </th>

                                <th>نوع المعامله </th>

                                <th>تاريخ الطلب</th>
                                <th>الحالة</th>
                                <th>AB screening</th>
                                <th>AB identification</th>
                                <th>AB titration</th>
                                <th>الخيارات</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $investigations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investigation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: center"><?php echo e($investigation->id); ?></td>
                                    <td style="text-align: center"><?php echo e($investigation->person->name ?? ''); ?></td>
                                    <td style="text-align: center"><?php echo e($investigation->person->gender ?? ''); ?></td>
                                    <td style="text-align: center"><?php echo e($investigation->person->birth_date ?? ''); ?></td>

                                    <td style="text-align: center"><?php echo e($investigation->type); ?></td>

                                    <td style="text-align: center"><?php echo e($investigation->created_at->format('y-m-d') ?? ''); ?>

                                    </td>
                                    <td style="text-align: center">
                                        <?php if($investigation->status == 'الانتظار'): ?>
                                            <span class="badge bg-soft-warning" style="font-size:small ">الإنتظار</span>
                                        <?php elseif($investigation->status == 'مكتمل'): ?>
                                            <span class="badge bg-soft-success" style="font-size:small ">مكتمل</span>
                                        <?php elseif($investigation->status == 'مرفوض'): ?>
                                            <span class="badge bg-soft-danger" style="font-size:small ">
                                                مرفوض
                                            </span>
                                        <?php elseif($investigation->status == 'ملغي'): ?>
                                            <span class="badge bg-soft-secondary" style="font-size:small ">ملغي</span>
                                        <?php endif; ?>
                                    </td>
                                    <?php $__currentLoopData = $investigation->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <td>
                                            <?php echo e($item->result); ?>


                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if(count($investigation->tests) == 1): ?>
                                        <td></td>
                                        <td></td>
                                    <?php elseif(count($investigation->tests) == 2): ?>
                                        <td></td>
                                    <?php elseif(count($investigation->tests) == 0): ?>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    <?php else: ?>
                                    <?php endif; ?>

                                    <td><?php echo $__env->make('partials.investigations-options', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>
                </div>
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('/assets/libs/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/libs/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/libs/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/js/pages/datatables.init.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable({
                responsive: true,
                autoWidth: false,
                order: [
                    [0, 'desc']
                ]

            });

        });
    </script>
    <script src="<?php echo e(URL::asset('/assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/js/pages/form-advanced.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/walieldin-nctr/Desktop/new blood/resources/views/all-investigations.blade.php ENDPATH**/ ?>