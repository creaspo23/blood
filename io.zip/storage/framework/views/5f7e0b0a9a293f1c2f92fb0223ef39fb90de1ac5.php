<div class="dropdown d-inline-block">
    <a type="button" class="btn btn-outline-primary" id="page-header-user-dropdown" data-bs-toggle="dropdown"
        aria-haspopup="true" aria-expanded="false">
        <i class="uil-ellipsis-v d-none d-xl-inline-block font-size-1"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-end">
        
        

        
        
        <a class="dropdown-item" href="<?php echo e(url('/tests/' . $test[0] . '/' . $type[0] . '/' . $kid->id)); ?>"> <span
                class="align-middle"> فحص الدم للطفل</span></a>
        

        
        

        
        
        <a class="dropdown-item" href="<?php echo e(url('/tests/' . $test[0] . '/' . $type[1] . '/' . $kid->mother_id)); ?>"> <span
            class="align-middle"> فحص الدم للأم</span></a>

             <a class="dropdown-item" 
         href="#" data-bs-toggle="modal"class="align-middle"
            data-bs-target="#myModal-block-branch-<?php echo e($kid->id); ?>">
            <?php echo e(__('فحص ال ICT ')); ?> </a>

            <a class="dropdown-item" 
            href="#" data-bs-toggle="modal"class="align-middle"
               data-bs-target="#myModal-block-DCT-<?php echo e($kid->id); ?>">
               <?php echo e(__('فحص ال DCT ')); ?> </a>

               <a class="dropdown-item" href="<?php echo e(route('kidInvoice', $kid->id)); ?>"> <span class="align-middle">
                طباعه </span>
        </a>
               
    </div>
</div>


<div id="myModal-block-branch-<?php echo e($kid->id); ?>" class="modal fade" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myModalLabel"><?php echo e(__('ICTTest')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" novalidate action="<?php echo e(route('ict')); ?>" method="POST">
                    <div class="row">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="kid_id" value="<?php echo e($kid->id); ?>">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="result"><?php echo e(__('ICT-Test')); ?></label>
                                <select name="result" class="form-control">
                                    <option value="postive">postive</option>
                                    <option value="negative">negative</option>
                                </select>
       
                                

                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div>
                    <button type="submit" class="btn  btn-primary"><?php echo e(__('save')); ?></button>

                </form>
            </div>

        </div>
    </div>
</div>



<div id="myModal-block-DCT-<?php echo e($kid->id); ?>" class="modal fade" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myModalLabel"><?php echo e(__('DCTTest')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" novalidate action="<?php echo e(route('dct')); ?>" method="POST">
                    <div class="row">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="kid_id" value="<?php echo e($kid->id); ?>">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="result"><?php echo e(__('DCT-Test')); ?></label>
                                <select name="result" class="form-control">
                                    <option value="postive">postive</option>
                                    <option value="negative">negative</option>
                                </select>
                                

                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div>
                    <button type="submit" class="btn  btn-primary"><?php echo e(__('save')); ?></button>

                </form>
            </div>

        </div>
    </div>
</div><?php /**PATH /home/walieldin-nctr/Desktop/new blood/resources/views/partials/kid-options.blade.php ENDPATH**/ ?>