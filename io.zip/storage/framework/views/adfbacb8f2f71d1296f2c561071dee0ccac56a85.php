<div class="dropdown d-inline-block">
    <a type="button" class="btn btn-outline-primary" id="page-header-user-dropdown" data-bs-toggle="dropdown"
        aria-haspopup="true" aria-expanded="false">
        <i class="uil-ellipsis-v d-none d-xl-inline-block font-size-1"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-end">
        <a class="dropdown-item" href="#" data-bs-toggle="modal"class="align-middle"
            data-bs-target="#myModal-block-DCT-<?php echo e($investigation->id); ?>">
            <?php echo e(__('فحص ال investigation ')); ?> </a>

        <a class="dropdown-item" href="<?php echo e(route('investigationsInvoice', $investigation->id)); ?>"> <span
                class="align-middle">
                طباعه </span>
        </a>
        <a class="dropdown-item" href="#" data-bs-toggle="modal"class="align-middle"
            data-bs-target="#myModal-block-status-<?php echo e($investigation->id); ?>">
            <?php echo e(__('تغير الحالة')); ?> </a>
        </a>
    </div>
</div>
<div id="myModal-block-DCT-<?php echo e($investigation->id); ?>" class="modal fade" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myModalLabel"><?php echo e(__('فحص ال investigation')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" novalidate
                    action="<?php echo e(route('investigations.update', $investigation->id)); ?>" method="post">
                    <div class="row">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($investigation->id); ?>">
                        <div class="col-md-12">
                            <div class="mb-3">

                                <?php $__currentLoopData = $investigation->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label for="result"
                                        style="margin-bottom: 10px; margin-top: 10px;"><?php echo e($item->test); ?>Test</label>
                                    <select name="results[<?php echo e($item->test); ?>]" class="form-control">
                                        <option value="postive">postive</option>
                                        <option value="negative">negative</option>
                                    </select>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div>
                    <button type="submit" class="btn  btn-primary"><?php echo e(__('save')); ?></button>

                </form>
            </div>

        </div>
    </div>
</div>


<div id="myModal-block-status-<?php echo e($investigation->id); ?>" class="modal fade" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myModalLabel"><?php echo e(__('تغير الحاله')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" novalidate
                    action="<?php echo e(route('investigationsStatus', $investigation->id)); ?>" method="post">
                    <div class="row">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($investigation->id); ?>">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="sat"><?php echo e(__('تغير الحالة')); ?></label>
                                <select name="status" class="form-control">
                                    <option value="الانتظار">الانتظار</option>
                                    <option value="مكتمل">مكتمل</option>
                                    <option value="ملغي">ملغي</option>
                                </select>
                            </div>

                            <!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div>
                    <button type="submit" class="btn  btn-primary"><?php echo e(__('save')); ?></button>

                </form>
            </div>

        </div>
    </div>
</div>
<?php /**PATH /home/walieldin-nctr/Desktop/new blood/resources/views/partials/investigations-options.blade.php ENDPATH**/ ?>